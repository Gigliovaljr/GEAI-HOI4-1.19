version="1.19"
tags={
	"Fixes"
}
name="Expert AI 5.0 Edited 1.19"
supported_version="1.19.2.0"